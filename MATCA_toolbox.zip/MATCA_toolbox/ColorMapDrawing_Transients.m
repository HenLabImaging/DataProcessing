function ColorMapDrawing_Transients(DATA)
    figure;imagesc(DATA');colorbar;colormap jet(20);
    xlabel('samples','FontSize',16);ylabel('cell','FontSize',16);
    set(gcf,'Color',[1 1 1])
end
