function CountEvents(fs,time1,time2,var1,var2,DATA)

    Nevents=var2-var1+1;
    
    Active_cells=zeros(1,Nevents);
    for i=1:Nevents    
%     for ii=1:num_Context
    Active_cells(i)=length(find(DATA(:,i)>0));
%     end
%     
%     Active_cells(i,:)=num_fires;
    
    end
        figure;subplot(211);bar(Active_cells,'r','LineWidth',2); xlabel('cell','FontSize',16);ylabel('#Events','FontSize',16);box off;set(gcf,'Color',[1 1 1])
%         size(Active_cells)

        edges=[0:length(Active_cells)]/length(Active_cells)
        subplot(212);histfit(Active_cells',10,'rayleigh'); xlabel('#Events','FontSize',16);ylabel('N of cells','FontSize',16);box off
        histc(Active_cells,0:10);
end
