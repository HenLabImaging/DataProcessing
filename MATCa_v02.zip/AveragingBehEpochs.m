function AveragingBehEpochs(fs,time1,time2,var1,var2,DATA)

% 
if nargin < 1;errordlg('Select data'); end;
if nargin < 2;errordlg('Sampling frequency required');end


% uiwait(msgbox('Enter your behavioral data!'))
% [beh dir]=uigetfile('.*','Enter behavior data');
% [pathdata,namedata,format]=fileparts(beh);
% 
% 
% 
% fs_video=round(length(beh)/(beh(end,1)-beh(1,1)));
% fs_in=char(inputdlg(['Is your video sampling rate: ' num2str(fs_video) '?' ' '  'y/n']));
% if(fs_in~='y')
%     fs_video=str2double(char(inputdlg('Enter the correct Video sampling rate:')));
% end
data=DATA;
Ncells=min(size(data));

fs_video=str2double(char(inputdlg('Enter your video sampling rate')));
beh=DataRead(fs_video,'','','','');

beh_column=str2double(char(inputdlg('Enter the behavioral column you like to analyze')));

sampling_conv=fs_video/fs;

TimeW=str2double(char(inputdlg('Enter a Time Window size in seconds: ')));
if(isnan(TimeW))
    TimeW=10;
    errordlg('Time Window was skipped, default window is 10 sec')
end

% data=DataRead(5.'','','','');
% data=DATA(:,2:end);

% timeind=round(beh(find(beh(:,3)>0),2));
% dtimeind= diff(timeind);
% 
% intertimeind=find(dtimeind>10);
% timeind(intertimeind)
% 

norm_data=normdata(data);

data=norm_data;

% [pks,locs]=findpeaks(beh(:,3),30)
[pks,locs]=findpeaks(beh(:,beh_column));
datalocs=round(locs/sampling_conv);

beh_epochs=[];
TimeWW=fs*TimeW;

rmdown=find(datalocs<TimeW);
rmup=find(datalocs>length(data));
datalocs(rmdown)=[];
datalocs(rmup)=[];


for i=1:length(datalocs)
beh_epochs(i,:,:)=data(datalocs(i)-TimeWW+1:datalocs(i)+TimeWW,:);
end

t=linspace(-TimeW,TimeW,length(beh_epochs))

figure;subplot(4,1,1:3);imagesc(t,1:Ncells,squeeze(mean(beh_epochs))');title(['N of averaged epochs:' num2str(length(datalocs))])
xlabel('seconds');ylabel('cells');hold on;plot([0 0],[1 Ncells],'w:','LineWidth',3)
subplot(4,1,4);plot(t,mean(squeeze(mean(beh_epochs))'),'k','LineWidth',2);box off
end