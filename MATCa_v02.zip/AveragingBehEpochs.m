function AveragingBehEpochs(fs,time1,time2,var1,var2,DATA)

% 
if nargin < 1;errordlg('Select data'); end;
if nargin < 2;errordlg('Sampling frequency required');end
%%

% uiwait(msgbox('Enter your behavioral data!'))
% [beh dir]=uigetfile('.*','Enter behavior data');
% [pathdata,namedata,format]=fileparts(beh);
% 
% 
% 
% fs_video=round(length(beh)/(beh(end,1)-beh(1,1)));
% fs_in=char(inputdlg(['Is your video sampling rate: ' num2str(fs_video) '?' ' '  'y/n']));
% if(fs_in~='y')
%     fs_video=str2double(char(inputdlg('Enter the correct Video sampling rate:')));
% end
data=DATA;
Ncells=min(size(data));

fs_video=str2double(char(inputdlg('Enter your video sampling rate')));
beh=DataRead(fs_video,'','','','');

beh_column=str2double(char(inputdlg('Enter the behavioral column you like to analyze')));

sampling_conv=fs_video/fs;

TimeW=str2double(char(inputdlg('Enter a Time Window size in seconds: ')));
if(isnan(TimeW))
    TimeW=10;
    errordlg('Time Window was skipped, default window is 10 sec')
end

% data=DataRead(5.'','','','');
% data=DATA(:,2:end);

% timeind=round(beh(find(beh(:,3)>0),2));
% dtimeind= diff(timeind);
% 
% intertimeind=find(dtimeind>10);
% timeind(intertimeind)
% 

norm_data=normdata(data);

data=norm_data;

% [pks,locs]=findpeaks(beh(:,3),30)
[pks,locs]=findpeaks(beh(:,beh_column));
datalocs=round(locs/sampling_conv);

beh_epochs=[];
TimeWW=fs*TimeW;

rmdown=find(datalocs<TimeW);
rmup=find(datalocs>length(data));
datalocs(rmdown)=[];
datalocs(rmup)=[];


for i=1:length(datalocs)
beh_epochs(i,:,:)=data(datalocs(i)-TimeWW+1:datalocs(i)+TimeWW,:);
end

t=linspace(-TimeW,TimeW,length(beh_epochs));

average_beh_epoch=squeeze(mean(beh_epochs));

TFIDF=average_beh_epoch';Rated_bigXtoX=[];
temp22=0;
% TFIDF=dg1A';
mean2bigXtoX=[];
mean2bigXtoX=max(TFIDF(:,1:TimeWW)');
% Rated_bigXtoX=TFIDF;
sortedmeanbigXtoX=sort(mean2bigXtoX,'ascend');
for i=1:min(size(TFIDF))
temp2=find(mean2bigXtoX==sortedmeanbigXtoX(i));
if(length(temp2)>1)
for k=1:length(temp22)
aa=find(temp2==temp22(k));
temp2(aa)=[];
end
end
temp22(i)=min(temp2);
Rated_bigXtoX(i,:)=TFIDF(temp22(i),:);
end
% figure;pcolor(Rated_bigXtoX);shading flat;colormap jet(20);



figure;subplot(7,1,1:3);pcolor(t,1:Ncells,average_beh_epoch');title(['N of averaged epochs:' num2str(length(datalocs))]);
shading flat;colormap jet(20);xlabel('seconds');ylabel('cells');hold on;plot([0 0],[1 Ncells],'w:','LineWidth',3)
subplot(7,1,4:6);pcolor(t,1:Ncells,Rated_bigXtoX);title(['N of averaged epochs:' num2str(length(datalocs))]);
shading flat;colormap jet(20);
xlabel('seconds');ylabel('cells');hold on;plot([0 0],[1 Ncells],'w:','LineWidth',3)
subplot(7,1,7);plot(t,mean(squeeze(mean(beh_epochs))'),'k','LineWidth',2);box off;axis tight
end